Name: webpa-lti
Author: Stephen P Vickers
Documentation: http://www.spvsoftwareproducts.com/php/webpa-lti/
Source files: https://github.com/celtic-project/webpa-lti
Installation files: https://github.com/OSCELOT/webpa-lti
