Name: webpa-lti
Author: Stephen P Vickers
Documentation: https://github.com/celtic-project/webpa-lti/wiki
Source files: https://github.com/celtic-project/webpa-lti
Installation files: https://github.com/OSCELOT/webpa-lti
