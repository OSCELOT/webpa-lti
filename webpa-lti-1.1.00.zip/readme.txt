Name: webpa-lti
Author: Stephen P Vickers
Download: http://projects.oscelot.org/gf/project/webpa-lti/
Documentation: http://www.spvsoftwareproducts.com/php/webpa-lti/
